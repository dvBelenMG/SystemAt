<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <title>Document</title>
</head>
<body>
    

<div class="row">
    <div class="col-md-4 col-lg-4 col-md-4 bg-dark">
        
    </div>
    <div class="col-md-8 col-lg-8 col-md-8 bg-success">
        hol
    </div>
</div>

</body>
</html>