<div class="offcanvas offcanvas-start" tabindex="-1" id="offcanvasMenu" aria-labelledby="offcanvasMenuLabel">
  <div class="offcanvas-header">
    <h5 class="offcanvas-title" id="offcanvasMenuLabel">Abilitytalk</h5>
    <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
  </div>
  <div class="offcanvas-body">
    <div class="row mt-2">
        <p><img src="img/home.svg" class="p-2" srcset="">inicio</p>
    </div>
    <div class="row mt-2">
        <a href="ajustes.html" class="text-decoration-none text-dark">
        <p><img src="img/settings-sharp.svg" class="p-2" srcset="">ajustes</p>
    </div>
    <div class="row mt-2">
        <p><img src="img/comment.svg" class="p-2" srcset="">mensajes</p>
    </div>
    <div class="row mt-2">
        <a href="perfil2.php" class="text-decoration-none text-dark">
        <p><img src="img/user-avatar-filled.svg" class="p-2" srcset="">perfil</p>
    </div>
  </div>
</div>