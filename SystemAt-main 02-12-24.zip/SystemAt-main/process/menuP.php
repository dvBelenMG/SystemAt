<div class="offcanvas offcanvas-start" tabindex="-1" id="offcanvasMenu" aria-labelledby="offcanvasMenuLabel">
  <div class="offcanvas-header">
    <h5 class="offcanvas-title" id="offcanvasMenuLabel">Abilitytalk</h5>
    <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
  </div>
  <div class="offcanvas-body">
    <div class="row mt-2">
        <p><img src="img/home.svg" alt="" srcset="">inicio</p>
    </div>
    <div class="row mt-2">
        <p><img src="img/settings-sharp.svg" alt="" srcset="">ajustes</p>
    </div>
    <div class="row mt-2">
    <p><img src="img/user-avatar-filled.svg" alt="" srcset="">perfil</p>
    </div>
  </div>
</div>