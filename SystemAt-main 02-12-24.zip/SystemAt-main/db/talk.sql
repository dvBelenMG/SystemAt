-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 09-11-2024 a las 03:40:58
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `talk`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estadoexpediente`
--

CREATE TABLE `estadoexpediente` (
  `id_EstadoExpediente` int(11) NOT NULL,
  `NomEstado` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `estadoexpediente`
--

INSERT INTO `estadoexpediente` (`id_EstadoExpediente`, `NomEstado`) VALUES
(1, 'Validado'),
(2, 'Sin Validar');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estadop`
--

CREATE TABLE `estadop` (
  `ID_Estado_P` int(11) NOT NULL,
  `Descripcion` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `estadop`
--

INSERT INTO `estadop` (`ID_Estado_P`, `Descripcion`) VALUES
(1, 'diagnosticado'),
(2, 'en proceso'),
(3, 'dado de alta');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estadousuario`
--

CREATE TABLE `estadousuario` (
  `Id_EstadoUsuario` int(11) NOT NULL,
  `NomEstado` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `estadousuario`
--

INSERT INTO `estadousuario` (`Id_EstadoUsuario`, `NomEstado`) VALUES
(1, 'Online\r\n'),
(2, 'Offline'),
(3, 'Suspendido');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `expedienteespecialista`
--

CREATE TABLE `expedienteespecialista` (
  `ID_ExpedienteEspecialista` int(11) NOT NULL,
  `Direccion` varchar(255) NOT NULL,
  `Cedula_Profecional` varchar(255) NOT NULL,
  `Especialidad` varchar(255) NOT NULL,
  `Universidad` varchar(255) NOT NULL,
  `id_Usuario` int(11) NOT NULL,
  `id_EstadoExpediente` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `expedienteespecialista`
--

INSERT INTO `expedienteespecialista` (`ID_ExpedienteEspecialista`, `Direccion`, `Cedula_Profecional`, `Especialidad`, `Universidad`, `id_Usuario`, `id_EstadoExpediente`) VALUES
(1, 'Av. Médica 1, Ciudad X', 'CED123456', 'Logopedia', 'unam', 4, 2),
(2, 'Av. Médica 2, Ciudad Y', 'CED234567', 'Terapia del Lenguaje', 'ANAHAC', 5, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `expedientepaciente`
--

CREATE TABLE `expedientepaciente` (
  `ID_ExpedientePaciente` int(11) NOT NULL,
  `Direccion` varchar(255) NOT NULL,
  `NumSeguro` int(11) NOT NULL,
  `HIstorial_Medico` varchar(255) NOT NULL,
  `Curp` varchar(255) NOT NULL,
  `id_Usuario` int(11) NOT NULL,
  `id_estado_P` int(11) NOT NULL,
  `id_EstadoExpediente` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `expedientepaciente`
--

INSERT INTO `expedientepaciente` (`ID_ExpedientePaciente`, `Direccion`, `NumSeguro`, `HIstorial_Medico`, `Curp`, `id_Usuario`, `id_estado_P`, `id_EstadoExpediente`) VALUES
(1, 'Calle 1, Ciudad A', 123456, 'Sin antecedentes', 'AERI070411HMCHVS09', 1, 1, 2),
(2, 'Calle 2, Ciudad B', 234567, 'Alergia a penicilina', 'AAGL070213MMCLRS05', 2, 2, 2),
(3, 'Calle 3, Ciudad C', 345678, 'Asma leve', 'AAGA070605HMCLNX02', 3, 3, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `genero`
--

CREATE TABLE `genero` (
  `ID_Genero` int(11) NOT NULL,
  `NombreG` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `genero`
--

INSERT INTO `genero` (`ID_Genero`, `NombreG`) VALUES
(1, 'Masculino'),
(2, 'Femenino'),
(3, 'Prefiero no decirlo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `test`
--

CREATE TABLE `test` (
  `ID_Test` int(11) NOT NULL,
  `NombreTest` varchar(55) NOT NULL,
  `id_Usuario` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `test`
--

INSERT INTO `test` (`ID_Test`, `NombreTest`, `id_Usuario`) VALUES
(1, 'Test de Articulación', 1),
(2, 'Test de Comprensión Auditiva', 2),
(3, 'Test de Fluidez Verbal', 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipousuario`
--

CREATE TABLE `tipousuario` (
  `ID_Tusuario` int(11) NOT NULL,
  `NombreTusuario` varchar(55) NOT NULL,
  `Descripcion` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `tipousuario`
--

INSERT INTO `tipousuario` (`ID_Tusuario`, `NombreTusuario`, `Descripcion`) VALUES
(1, 'U_Tecnico', 'Administra el aplicativo'),
(2, 'U_Tutor', 'Supervisa al paciente'),
(3, 'U_Paciente', 'Utiliza la app final'),
(4, 'U_Especialista', 'Da seguimmiento al paciente');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tratamiento`
--

CREATE TABLE `tratamiento` (
  `ID_Tratamiento` int(11) NOT NULL,
  `NombreTratamiento` varchar(55) NOT NULL,
  `id_Test` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `tratamiento`
--

INSERT INTO `tratamiento` (`ID_Tratamiento`, `NombreTratamiento`, `id_Test`) VALUES
(1, 'Tratamiento de voz', 1),
(2, 'Tratamiento de lenguaje', 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `ID_Usuario` int(11) NOT NULL,
  `NombreUser` varchar(55) NOT NULL,
  `ApellidoP` varchar(55) NOT NULL,
  `ApellidoM` varchar(55) NOT NULL,
  `Telefono` varchar(10) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `FechaNac` date NOT NULL,
  `FechaReg` date NOT NULL,
  `Password` varchar(55) NOT NULL,
  `id_EstadoUsuario` int(11) NOT NULL,
  `ID_Tusuario` int(11) NOT NULL,
  `ID_Genero` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`ID_Usuario`, `NombreUser`, `ApellidoP`, `ApellidoM`, `Telefono`, `Email`, `FechaNac`, `FechaReg`, `Password`, `id_EstadoUsuario`, `ID_Tusuario`, `ID_Genero`) VALUES
(1, 'Issac Enrique', 'Ahedo', 'Rivera', '5634240929', 'iahedo1022@conalepmex.edu.mx', '2007-04-11', '2024-10-09', '827ccb0eea8a706c4c34a16891f84e7b', 2, 3, 1),
(2, 'Leslie Gabriela', 'Alvarado', 'Garcia', '5581880647', 'lalvarado1322@conalepmex.edu.mx', '2007-02-13', '2024-10-09', '827ccb0eea8a706c4c34a16891f84e7b', 2, 3, 2),
(3, 'Angel Uriel', 'Alvarez', 'Gonazalez', '5529959102', 'aalvarez20822@conalepmex.edu.mx', '2007-06-05', '2024-10-09', '827ccb0eea8a706c4c34a16891f84e7b', 2, 3, 1),
(4, 'Nereida', 'Arevalo', 'Diego', '563850598', 'narevalo1922@conalepmex.edu.mx', '2007-05-20', '2024-10-09', '827ccb0eea8a706c4c34a16891f84e7b', 2, 4, 2),
(5, 'Kevin Emmanuel', 'Argueta', 'Alcala', '5555036595', 'kargueta0922@conalepmex.edu.mx', '2007-08-10', '2024-10-09', '827ccb0eea8a706c4c34a16891f84e7b', 2, 4, 1);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `estadoexpediente`
--
ALTER TABLE `estadoexpediente`
  ADD PRIMARY KEY (`id_EstadoExpediente`);

--
-- Indices de la tabla `estadop`
--
ALTER TABLE `estadop`
  ADD PRIMARY KEY (`ID_Estado_P`);

--
-- Indices de la tabla `estadousuario`
--
ALTER TABLE `estadousuario`
  ADD PRIMARY KEY (`Id_EstadoUsuario`);

--
-- Indices de la tabla `expedienteespecialista`
--
ALTER TABLE `expedienteespecialista`
  ADD PRIMARY KEY (`ID_ExpedienteEspecialista`),
  ADD KEY `id_Usuario` (`id_Usuario`),
  ADD KEY `id_EstadoExpediente` (`id_EstadoExpediente`);

--
-- Indices de la tabla `expedientepaciente`
--
ALTER TABLE `expedientepaciente`
  ADD PRIMARY KEY (`ID_ExpedientePaciente`),
  ADD KEY `id_Usuario` (`id_Usuario`),
  ADD KEY `id_estado_P` (`id_estado_P`),
  ADD KEY `id_EstadoExpediente` (`id_EstadoExpediente`);

--
-- Indices de la tabla `genero`
--
ALTER TABLE `genero`
  ADD PRIMARY KEY (`ID_Genero`);

--
-- Indices de la tabla `test`
--
ALTER TABLE `test`
  ADD PRIMARY KEY (`ID_Test`),
  ADD KEY `id_Usuario` (`id_Usuario`);

--
-- Indices de la tabla `tipousuario`
--
ALTER TABLE `tipousuario`
  ADD PRIMARY KEY (`ID_Tusuario`);

--
-- Indices de la tabla `tratamiento`
--
ALTER TABLE `tratamiento`
  ADD PRIMARY KEY (`ID_Tratamiento`),
  ADD KEY `id_Test` (`id_Test`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`ID_Usuario`),
  ADD KEY `fk_usuarios_genero` (`ID_Genero`),
  ADD KEY `fk_usuarios_tipousuario` (`ID_Tusuario`),
  ADD KEY `id_EstadoUsuario` (`id_EstadoUsuario`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `estadoexpediente`
--
ALTER TABLE `estadoexpediente`
  MODIFY `id_EstadoExpediente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `estadousuario`
--
ALTER TABLE `estadousuario`
  MODIFY `Id_EstadoUsuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `ID_Usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `expedienteespecialista`
--
ALTER TABLE `expedienteespecialista`
  ADD CONSTRAINT `expedienteespecialista_ibfk_1` FOREIGN KEY (`id_Usuario`) REFERENCES `usuarios` (`ID_Usuario`),
  ADD CONSTRAINT `expedienteespecialista_ibfk_2` FOREIGN KEY (`id_EstadoExpediente`) REFERENCES `estadoexpediente` (`id_EstadoExpediente`);

--
-- Filtros para la tabla `expedientepaciente`
--
ALTER TABLE `expedientepaciente`
  ADD CONSTRAINT `expedientepaciente_ibfk_1` FOREIGN KEY (`id_Usuario`) REFERENCES `usuarios` (`ID_Usuario`),
  ADD CONSTRAINT `expedientepaciente_ibfk_2` FOREIGN KEY (`id_estado_P`) REFERENCES `estadop` (`ID_Estado_P`),
  ADD CONSTRAINT `expedientepaciente_ibfk_3` FOREIGN KEY (`id_EstadoExpediente`) REFERENCES `estadoexpediente` (`id_EstadoExpediente`);

--
-- Filtros para la tabla `test`
--
ALTER TABLE `test`
  ADD CONSTRAINT `test_ibfk_1` FOREIGN KEY (`id_Usuario`) REFERENCES `usuarios` (`ID_Usuario`);

--
-- Filtros para la tabla `tratamiento`
--
ALTER TABLE `tratamiento`
  ADD CONSTRAINT `tratamiento_ibfk_1` FOREIGN KEY (`id_Test`) REFERENCES `test` (`ID_Test`);

--
-- Filtros para la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `usuarios_ibfk_1` FOREIGN KEY (`ID_Tusuario`) REFERENCES `tipousuario` (`ID_Tusuario`),
  ADD CONSTRAINT `usuarios_ibfk_2` FOREIGN KEY (`ID_Genero`) REFERENCES `genero` (`ID_Genero`),
  ADD CONSTRAINT `usuarios_ibfk_3` FOREIGN KEY (`id_EstadoUsuario`) REFERENCES `estadousuario` (`Id_EstadoUsuario`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
