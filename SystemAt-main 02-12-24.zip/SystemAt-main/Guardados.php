<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/dash1.css">
    <link rel="stylesheet" href="css/ajustes.css">
    <title>Document</title>
</head>
<body>
    <nav class="navbar navbar-light bg-light shadow">
        <div class="container-fluid">
            <a class="icon nav-link active" href="dashboardT.php" role="button">
                <img src="img/Back.svg" width="40px" alt="">
            </a>
            <a class="navbar-brand mx-auto" href="#">
                <h4>Guardados</h4>
            </a>
        </div>
    </nav>

            <!--barra de busqueda-->
            <div class="row justify-content-center mt-5 text-center">
                <div class="col-sm-11 col-md-11 col-md-11">
                    <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                    <br>
                    <h3>Folletos Informativos</h3>
                </div>
            </div>
            
<div class="d-flex align-items-center justify-content-center min-vh-50">
    <div class="mt-4">
        <div class="card mb-3" style="max-width: 540px;">
            <div class="row g-0">
                <div class="col-md-4">
                    <img src="img/CMLS.png" class="img-fluid rounded-start" alt="...">
                </div>
                <div class="col-md-8">
                    <div class="card-body">
                        <h5 class="card-title">¿Cómo manejar la situacion?</h5>
                        <a href="#" class="btn btn-info w-50" style="color: white;">Leer</a>
                    </div>
                </div>
            </div>
        </div>

        <div class="card mb-3" style="max-width: 540px;">
            <div class="row g-0">
                <div class="col-md-4">
                    <img src="img/CSCPA.png" class="img-fluid rounded-start" alt="...">
                </div>
                <div class="col-md-8">
                    <div class="card-body">
                        <h5 class="card-title">¿Cómo saber cuando pedir ayuda?</h5>
                        <a href="#" class="btn btn-info w-50" style="color: white;">Leer</a>
                    </div>
                </div>
            </div>
        </div>

        <div class="card mb-3" style="max-width: 540px;">
            <div class="row g-0">
                <div class="col-md-4">
                    <img src="img/CPAMH.png" class="img-fluid rounded-start" alt="...">
                </div>
                <div class="col-md-8">
                    <div class="card-body">
                        <h5 class="card-title">¿Cómo puedo ayudar a mi hijo?</h5>
                        <a href="#" class="btn btn-info w-50" style="color: white;">Leer</a>
                    </div>
                </div>
            </div>
        </div>

        <div class="card mb-3" style="max-width: 540px;">
            <div class="row g-0">
                <div class="col-md-4">
                    <img src="img/CSLLSEC.png" class="img-fluid rounded-start" alt="...">
                    </div>
                <div class="col-md-8">
                    <div class="card-body">
                        <h5 class="card-title">¿Cómo sobre llevar la <br> situación en casa?</h5>
                        <a href="#" class="btn btn-info w-50" style="color: white;">Leer</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


    </div>
</div>
</body>
</html>