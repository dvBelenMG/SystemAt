function validar(){

    var nombre = document.getElementById^['Nombre'];
    var Ap = document.getElementById['Ap'];
    var am = document.getElementById['Am'];
    var email = document.getElementById['Email'];
    var pass = document.getElementById['Pass'];
    var tel = document.getElementById['Telefono'];
    var grupo = document.getElementById['Grupo'];

    if(nombre == null){
        alert ('el campo nombre esta vacío');
    }
   /* else if(Ap == ' '){
        alert ("el campo Apellido Paterno Esata Vacio");
    }
    else if(am == ' '){
        alert("el campo Apellido Paterno Esata Vacio");
    }
    else if(email == ' '){
        alert ("el campo Apellido Paterno Esata Vacio");
    }
    else if(pass ==' '){
        alert ("el campo Apellido Paterno Esata Vacio");
    }
    else if(tel == ' '){
        alert ("el campo Apellido Paterno Esata Vacio");
    }
    else if (grupo == " "){

        alert ("el campo grupo");
    }*/

}